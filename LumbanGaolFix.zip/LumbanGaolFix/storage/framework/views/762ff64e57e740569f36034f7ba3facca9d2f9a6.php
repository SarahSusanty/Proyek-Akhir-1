<?php $__env->startSection('title', 'Admin'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="/css/admin.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="header-right shadow-sm">
        <h4><span><i class="fas fa-server"></i></span><span>Data Web</span></h4>
        <p>Data Web / </p>
    </div>
    <div class="content-right">
        <div class="bigContent">
            <h5>Lakukan perubahan web dengan memilih menu di bawah!</h5>
            <div class="rowTypes">
                <div class="listType color1 shadow-sm" onclick="return redirect('/admin/Data/<?php echo e($type[0]->type); ?>', false)">
                    <i class="fas fa-link"></i>
                    <?php echo e($type[0]->type); ?>

                </div>
                <div class="listType color2 shadow-sm" onclick="return redirect('/admin/Data/<?php echo e($type[1]->type); ?>',false)">
                    <i class="fas fa-sliders-h"></i>
                    <?php echo e($type[1]->type); ?>

                </div>
                <div class="listType color3 shadow-sm"  onclick="return redirect('/admin/Data/<?php echo e($type[2]->type); ?>', false)">
                    <i class="fas fa-heading"></i>
                    <?php echo e($type[2]->type); ?>

                </div>
                <div class="listType color4 shadow-sm"  onclick="return redirect('/admin/Data/<?php echo e($type[3]->type); ?>', false)">
                    <i class="fas fa-file-alt"></i>
                    <?php echo e($type[3]->type); ?>

                </div>
                <div class="listType color5 shadow-sm"  onclick="return redirect('/admin/Data/<?php echo e($type[4]->type); ?>', false)">
                    <i class="fab fa-reddit"></i>
                    <?php echo e($type[4]->type); ?>

                </div>
                <div class="listType color6 shadow-sm"  onclick="return redirect('/admin/Data/<?php echo e($type[5]->type); ?>', false)">
                    <i class="fas fa-image"></i>
                    <?php echo e($type[5]->type); ?>

                </div>
            </div>
            <div class="rules shadow">
                <h5><?php echo e($rules->name); ?></h5>
                <?php echo $rules->information; ?>

            </div>
        </div>
    </div>
    <div class="footer-right">
        <p><?php echo e($crfoot->information); ?></p>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('edit-js'); ?>
    <script src="<?php echo e(asset('js/admin.js')); ?>" defer></script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultfour', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/admin/dataWeb.blade.php ENDPATH**/ ?>