<?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="listForum shadow" >
    <div class="float-right">
        <a href="/admin/forum/edit/<?php echo e(base64_encode($item->id)); ?>"><i class="fas fa-edit"></i></a>
    </div>
    <?php if($item->counts != 0): ?>
    <div class="pesanbaru"><?php echo e($item->counts); ?></div>
    <?php endif; ?>
    <div class="flex-baru-row" onclick="window.location.href='/admin/forum/<?php echo e(base64_encode($item->id)); ?>/messages'">
        <div class="logoForum">
            <img src="/uploads/img/Forums/Logo/<?php echo e($item->logo); ?>" alt="">
        </div>
        <div class="descForum ml-2">
            <h6><?php echo e($item->name); ?></h6>
            <?php echo $item->description; ?>

        </div>
    </div>
    <div class="float-right">
        <a href="/admin/forum/participants/<?php echo e(base64_encode($item->id)); ?>" class="btn btn-info"><i class="fas fa-user-friends"></i></a>
        <a href="" class="btn btn-danger" onclick="return deleteForum(this)" data-id='<?php echo e($item->id); ?>'><i class="fas fa-trash-alt"></i></a>
    </div>
    <div class="clear"></div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($forums->links()); ?>

<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/admin/rowForums.blade.php ENDPATH**/ ?>