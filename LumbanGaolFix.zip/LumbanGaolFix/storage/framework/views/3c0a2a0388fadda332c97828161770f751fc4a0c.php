<?php $__env->startSection('title', 'Informasi'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="/css/informasi.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="padding-default">
    <div class="headerPage" style="background: url(<?php echo e(asset('uploads/img/AsetWeb/'.$bgHead->picture)); ?>)" data-aos="fade-down">
        <h2><?php echo e($header->name); ?></h2>
        <?php echo $header->information; ?>

    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/informasi">Informasi</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($informasi->title); ?></li>
        </ol>
    </nav>
    <div class="contentRow flex-baru-row">
        <div class="leftSide">
            <div class="contentLeft">
                <?php if($informasi !== Null): ?>
                <div class="listInformasi shadow" data-aos="flip-left">
                    <div class="displayImg">
                        <img src="/uploads/img/Album/<?php echo e($informasi->name); ?>" alt="">
                    </div>
                    <h4><?php echo e($informasi->title); ?></h4>
                    <div class="garis-bawah"></div>
                    <div class="decTetx">
                        <?php echo $informasi->content; ?>

                    </div>
                    <small><?php echo e($informasi->created_at); ?></small>
                </div>
                <?php else: ?>
                    <h5>Tidak Ada Informasi Ditemukan</h5>
                <?php endif; ?>
            </div>
        </div>
        <div class="rightSide">
            <div class="boxSearch">
                <form action="/informasi/cari/" method="get">
                    <input type="text" name="key" id="" placeholder="Cari informasi di sini">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
            <div class="rekomendasi">
                <h5>Sering Dibaca</h5>
                <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="listRekomendasi shadow" data-aos="flip-down" onclick="window.location.href='/informasi/baca/<?php echo e(base64_encode($item->id)); ?>'">
                    <div class="miniDisplay">
                        <img src="/uploads/img/Album/<?php echo e($item->name); ?>" alt="">
                    </div>
                    <div class="desc">
                        <h6><?php echo e($item->title); ?></h6>
                        <small><?php echo e($item->created_at); ?></small>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="category">
                <h5>Kategori</h5>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/informasi/category/<?php echo e(base64_encode($item->id)); ?>"><?php echo e($item->category); ?> (<?php if($item->jumlah > 0): ?>
                        <?php echo e($item->jumlah); ?>

                    <?php else: ?>
                        0
                    <?php endif; ?>)</a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<div class="footer">
    <p><?php echo $crfoot->information; ?></p>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('edit-js'); ?>
    <script src="<?php echo e(asset('js/informasi.js')); ?>" defer  ></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/informasi/read.blade.php ENDPATH**/ ?>