<?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="listForum shadow">
    <div class="flex-baru-row">
        <div class="logoForum">
            <img src="/uploads/img/Forums/Logo/<?php echo e($item->logo); ?>" alt="">
        </div>
        <div class="descForum ml-2">
            <h5><?php echo e($item->name); ?></h5>
            <?php echo $item->description; ?>

        </div>
    </div>
    <a onclick='return requestJoin("<?php echo e(base64_encode($item->id)); ?>")' href="#" class="btn btn-success"><i class="fas fa-sign-in-alt"></i> Request Join Forum</a>
    <div class="clear"></div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($forums->links()); ?>

<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/pengunjung/rowForumsJoin.blade.php ENDPATH**/ ?>