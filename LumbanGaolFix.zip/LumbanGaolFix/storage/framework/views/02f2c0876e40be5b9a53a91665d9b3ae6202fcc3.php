<?php $__currentLoopData = $aspirations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="listAspirasi shadow">
    <div class="userInfo">
        <img src="/uploads/img/UserProfile/<?php echo e($item->profile); ?>" alt="">
        <h6><?php echo e($item->name); ?></h6>
    </div>
    <div class="aspirasi">
        <h6>Topik: <?php echo e($item->topic); ?></h6>
        <?php echo $item->aspiration; ?>

    </div>
    <?php if($item->status == 'approved'): ?>
        <div class="approved">
            <i class="fas fa-check"></i>
            Diterima
        </div>
    <?php else: ?>
        <?php if($item->status == 'waiting'): ?>
            <div class="waiting">
                <i class="fas fa-stopwatch"></i>
                Menunggu
            </div>
        <?php else: ?>
            <?php if($item->status == 'rejected'): ?>
                <div class="rejected">
                    <i class="fas fa-times-circle"></i>
                    Ditolak
                </div>
            <?php else: ?>
                <div class="rejected">
                    <i class="fas fa-ban"></i>
                    Diblokir
                </div>
            <?php endif; ?>

        <?php endif; ?>
    <?php endif; ?>
    <strong><?php echo e($item->created_at); ?></strong>
    <a href="#" class="btn btn-danger" onclick="return confirmAspirasi('batalkan',<?php echo e($item->id); ?> ,'/admin/aspirasi/menunggu', this)">
        <i class="fas fa-ban"></i> <span class='text-btn'>Batalkan Konfirmasi</span>
        <span class="spinner-border spinner-border-sm displayNone icon-loading"></span>
        <span class='text-loading displayNone'>Sedang Membatalkan Konfirmasi</span>
    </a>
    <div class="clear"></div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($aspirations->links()); ?>

<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/admin/rowAspirasi.blade.php ENDPATH**/ ?>