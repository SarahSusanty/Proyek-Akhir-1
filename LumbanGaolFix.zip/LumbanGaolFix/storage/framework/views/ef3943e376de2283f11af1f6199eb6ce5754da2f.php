<?php $__env->startSection('title', 'Admin'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="/css/admin.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="header-right shadow-sm">
        <h4><span><i class="fas fa-images"></i></span><span>Galeri</span></h4>
        <p><a href="/admin/galeri">Galeri</a> / <a href="/admin/galeri/contents/<?php echo e($idAlbum); ?>">Contents </a> /
            <?php echo e($album->name); ?> / Tambah Video</p>
    </div>
    <div class="content-right">
        <div class="bigContent">
            <div class="settings mb-3">
                <button class="btn btn-info" id="checkAll"><i class="fas fa-check-square"></i> Tandai Semua</button>
                <button class="btn btn-warning displayNone" id="uncheckAll"><i class="far fa-window-close"></i> Batalkan
                    Menandai</button>
            </div>
            <button class="btn btn-danger"><i class="fas fa-trash-alt"></i> Hapus</button>
            <table class="table">
                <thead>
                    <tr>
                        <th style="text-align: center">#</th>
                        <th style="text-align: center">Display</th>
                        <th style="text-align: center">Name</th>
                        <th style="text-align: center">Tanggal Dibuat</th>
                        <th style="text-align: center">Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($video[0] == null): ?>
                        <tr>
                            <td colspan='4'>
                                <p>Tidak Ada Video</p>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input type="checkbox" name="" id=""></td>
                                <td style="font-size: 40px;text-align: center;">
                                    <a target="_blank" href="<?php echo e($item->location . $item->name); ?>" data-placement="bottom"
                                        title="Tekan untuk melihat video"><i class="fas fa-file-video"></i></a>
                                </td>
                                <td style="text-align: center"><?php echo e($item->name); ?></td>
                                <td style="text-align: center"><?php echo e($item->created_at); ?></td>
                                <td style="text-align: center"><a href="" class="btn button-info"><i
                                            class="fas fa-plus"></i> Tambahkan ke album</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
        <div class="showImg pop-right">
            <img src="" alt="" width="100%">
        </div>
        <a href="#" data-toggle="modal" data-target="#myModal" id="add" class="btn" data-placement="bottom"
            title="Tekan untuk menambahkan item"><i class="fas fa-plus"></i></a>
    </div>
    <div class="footer-right">
        <p><?php echo e($crfoot->information); ?></p>
    </div>
    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Album</h4>
                    <a type="button" class="close" data-dismiss="modal">&times;</a>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="">Nama File</label>
                            <input type="text" name="" id="" class="form-control" placeholder="File Name">
                        </div>
                        <div class="form-group">
                            <label for="">Deskripsi Singkat</label>
                            <textarea name="" id="" cols="30" rows="5" class="form-control"></textarea>
                        </div>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input">
                            <label class="custom-file-label" for="customFile">Choose file</label>
                        </div>
                        <button type="submit" class="btn btn-success mt-3">Buat Album</button>
                    </form>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('edit-js'); ?>
    <script>
        $idAlbum = <?php echo e($idAlbum); ?>

    </script>
    <script src="<?php echo e(asset('js/admin.js')); ?>" defer></script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultfour', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/admin/galeriAddVideo.blade.php ENDPATH**/ ?>