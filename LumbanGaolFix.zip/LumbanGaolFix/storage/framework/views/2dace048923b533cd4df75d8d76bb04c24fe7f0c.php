<?php $__env->startSection('title', 'Galeri'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="/css/galeri.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="padding-default">
    <div id="AlbumDisplay" class="shadow">

    </div>
    <div class="Album mt60">
        <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="listAlbum shadow">
            <div class="displayAlbum">
                <img src="<?php echo e($item->location.$item->picture); ?>" alt="">
            </div>
            <div class="listDesc">
                <h6><?php echo e($item->name); ?></h6>
                <p><?php echo e($item->description); ?></p>
                <button class="btn button-info" onclick="setAlbum(<?php echo e($item->id); ?>)">Lihat Album</button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($albums->links()); ?>

    </div>
</div>
<div class="footer">
    <p><?php echo e($crfoot->information); ?></p>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('edit-js'); ?>
    <?php if(Session::has('idAlbum')): ?>
    <script>
        $idAlbum = <?php echo e(Session::get('idAlbum')); ?>;
    </script>
    <?php else: ?>
    <script>
        $idAlbum = <?php echo e($albums[0]->id); ?>;
    </script>
    <?php endif; ?>
    <script src="<?php echo e(asset('js/galeri.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/galeri/index.blade.php ENDPATH**/ ?>