    
    <?php $__env->startSection('title', 'Admin'); ?>
    <?php $__env->startSection('edit-css'); ?>
        <link rel="stylesheet" href="/css/admin.css">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <div class="header-right shadow-sm">
            <h4><span><i class="fas fa-comments"></i></span><span>Aspirasi</span></h4>
            <p>Forum / </p>
        </div>
        <div class="content-right">
            <div class="columns flex-baru-row">
                <div class="bigContent">
                    <h5>Buat Forum Baru</h5>
                    <form action="/admin/forum/edit/store" method="post" enctype="multipart/form-data" onsubmit="return submitFormRedirect(this, '/admin/forum')">
                        <input type="hidden" name="idForum" value="<?php echo e($forum->id); ?>">
                        <div class="form-group">
                            <label for="name">Nama Forum</label>
                            <input type="text" name="name" id="" class="form-control" required value="<?php echo e($forum->name); ?>">
                        </div>
                        <div class="form-group">
                            <label for="name">Deskripsi Forum</label>
                            <textarea name="description" id="" cols="30" rows="10" class="form-control" required ><?php echo e($forum->description); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="name">Logo</label><br>
                            <img src="/uploads/img/Forums/Logo/<?php echo e($forum->logo); ?>" alt="asdasd" width="40%">
                            <div class="custom-file mb-3 mt-60">
                                <input type="file" class="custom-file-input" id="file" name="file" >
                                <input type="hidden" name="oldLogo" value="<?php echo e($forum->logo); ?>">
                                <label class="custom-file-label" for="customFile">Choose file</label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success col-12">
                            <i class="fas fa-check-chircle"></i><span class='text-btn'>Simpan Perubahan</span>
                            <span class="spinner-border spinner-border-sm displayNone icon-loading"></span>
                            <span class='text-loading displayNone'> Sedang Menyimpan</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <div class="footer-right">
            <p><?php echo e($crfoot->information); ?></p>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('edit-js'); ?>
        <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
        <script>

        </script>
        <script src="//cdn.ckeditor.com/4.15.1/basic/ckeditor.js"></script>
        <script>
            CKEDITOR.replace('description');

        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultfour', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/admin/adminForumEdit.blade.php ENDPATH**/ ?>