<div class="bigDisplay">
   <?php $__currentLoopData = $picture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="display shadow">
    <img class="animasi-ketik" src="/uploads/img/Album/<?php echo e($item->name); ?>" alt="">
    </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="display shadow">
        <video controls src="/uploads/video/Album/<?php echo e($item->name); ?>"></video>
    </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <a href="#" id="prev" onclick="plusDisplay(-1)">&#10094;</a>
    <a href="#" id="next" onclick="plusDisplay(1)">&#10095;</a>
</div>
<div class="allInAlbum">
    <h6>Semua Gambar</h6>
    <div class="picture">
        <?php $__currentLoopData = $picture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="list" onclick="setDisplay(this)">
            <img src="/uploads/img/Album/<?php echo e($item->name); ?>" alt="" >
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <h6>Semua Video</h6>
    <div class="video">
        <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="list" onclick="setDisplay(this)">
            <video src="/uploads/video/Album/<?php echo e($item->name); ?>"></video>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/galeri/show.blade.php ENDPATH**/ ?>