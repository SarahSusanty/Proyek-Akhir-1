<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-default">
    <h3 class="center">Senang Bertemu Dengan Anda</h3>
    <p class="center">"Mari masuk untuk mengutarakan pendapat anda"</p>
    <div class="box-login shadow">
        <?php if(session('resent')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(__('Sebuah link untuk memastikan akun anda telah kami kirimkan ke alamat email anda.')); ?>

            </div>
        <?php endif; ?>

        <?php echo e(__('Sebelum memulai tolong periksa email anda.')); ?>

        <?php echo e(__('Jika anda masih belum menerima pesan (Coba cek ke dalam spam) atau kirim ulang')); ?>,
        <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit"
                class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('Kirim Ulang Link Verifikasi')); ?></button>.
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('edit-js'); ?>
    <script src="<?php echo e(asset('js/auth.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaulttwo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/auth/verify.blade.php ENDPATH**/ ?>