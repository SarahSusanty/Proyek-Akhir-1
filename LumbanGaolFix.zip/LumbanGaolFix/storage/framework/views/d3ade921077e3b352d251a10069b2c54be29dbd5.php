<table class="table table-striped">
    <thead class="table-dark">
        <tr>
            <th width="40px"> <input type="checkbox" id="" class="form-control"
                    onclick="check_uncheck_checkbox(this.checked, 'mark')"></th>
            <th width="40%">Judul</th>
            <th>Tanggal Buat</th>
            <th>Display</th>
            <th width="60px">Total Dibaca</th>
            <th>Edit</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $informations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <div class="form-group">
                        <input type="checkbox" name="mark" value="<?php echo e($item->id); ?>" id="" class="form-control">
                    </div>
                </td>
                <td><a target="_blank" href="/informasi/baca/<?php echo e(base64_encode($item->id)); ?>" data-toggle="tooltip"
                        title="Klik untuk melihat informasi"><?php echo e($item->title); ?></a></td>
                <td style="text-align: center;"><?php echo e($item->created_at); ?></td>
                <td style="text-align: center;"><img src="/uploads/img/Album/<?php echo e($item->name); ?>" alt="Display"
                        width="40px"></td>
                <td style="text-align: center;"><?php echo e($item->view); ?></td>
                <td style="text-align: center;"><a href="/admin/informasi/edit/<?php echo e($item->id); ?>"><i
                            class="fas fa-edit"></i> Edit</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php echo e($informations->links()); ?>


<script>
    $(document).ready(function() {
    $('td img').on('mouseenter', function() {
        $('.showImg').removeClass('visibility');
        $x = $(this).offset();
        $m = $('.showImg>img').height();
        $('.showImg>img').attr('src', $(this).attr('src'));
        $('.showImg').css({ 'left': ($x.left - 300) + 'px', top: ($x.top - $m - 20) + 'px' });
    });
    $('td img').on('mouseleave', function() {
        $('.showImg').addClass('visibility');
    });
    $('td img.pop-right').on('mouseenter', function() {
        $('.showImg').removeClass('visibility');
        $x = $(this).offset();
        $m = $('.showImg>img').height();
        $('.showImg>img').attr('src', $(this).attr('src'));
        $('.showImg').css({ 'left': ($x.left + $(this).width()) + 'px', top: ($x.top - $m + 20) + 'px' });
    });
    $('td img.pop-right').on('mouseleave', function() {
        $('.showImg').addClass('visibility');
    });
});

</script>
<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/admin/rowInformasi.blade.php ENDPATH**/ ?>