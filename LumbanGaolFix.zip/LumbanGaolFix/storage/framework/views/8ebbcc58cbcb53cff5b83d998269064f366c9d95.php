<?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="listForum shadow">
        <?php if($item->counts != 0): ?>
            <div class="pesanbaru"><?php echo e($item->counts); ?></div>
        <?php endif; ?>
        <div class="flex-baru-row">
            <div class="logoForum">
                <img src="/uploads/img/Forums/Logo/<?php echo e($item->logo); ?>" alt="">
            </div>
            <div class="descForum">
                <h5><?php echo e($item->name); ?></h5>
                <?php echo $item->description; ?>

            </div>
        </div>
        <a onclick="return ajaxSend('/pengunjung/forum/coba','post',{'idForum': <?php echo e($item->id); ?>}, null,[['liveSearch','/pengunjung/forum/ditolak/row','1', '.rowForums', key]], 'Apakah anda ingin mencoba bergabung kembali ?', 'Berhasil mengirim permintaan!') " href="/aspirasi" class="btn btn-warning"><i
                class="fas fa-sign-in-alt"></i>Coba untuk bergabung lagi </a>
        <div class="clear"></div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($forums->links()); ?>

<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/pengunjung/rowForumsDitolak.blade.php ENDPATH**/ ?>