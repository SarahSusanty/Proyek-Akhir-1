<?php $__env->startSection('title', 'Aspirasi'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="/css/aspirasi.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="padding-default">
        <div class="headerPage" style="background: url(<?php echo e(asset('uploads/img/AsetWeb/' . $bgHead->picture)); ?>)"
            data-aos="fade-down">
            <h2><?php echo e($header->name); ?></h2>
            <?php echo $header->information; ?>

        </div>
        <?php if(Session::has('AspirasiCari')): ?>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/aspirasi">Aspirasi</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Cari</li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(Session::get('AspirasiCari')); ?></li>
                </ol>
            </nav>
        <?php else: ?>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active" aria-current="page">Aspirasi</li>
                </ol>
            </nav>
        <?php endif; ?>
        <div class="contentRow">
            <div class="leftSide">
                <div class="contentLeft">
                    <?php if($aspirasi[0] !== null): ?>
                        <?php $__currentLoopData = $aspirasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="listAspirasi shadow" data-aos="flip-down">
                                <div class="headerList">
                                    <img src="/uploads/img/UserProfile/<?php echo e($item->profile); ?>" alt="User Profile">
                                    <h6><?php echo e($item->name); ?></h6>
                                </div>
                                <h6>Topik : <?php echo e($item->topic); ?></h6>
                                <div class="bodyList">
                                    <?php echo $item->aspiration; ?>

                                </div>
                                <div class="footerList">
                                    <a href="/aspirasi/tanggapan/<?php echo e($item->id); ?>" class="btn button-info">Lihat
                                        Tanggapan</a><br />
                                    <small> Jumlah Tanggapan :
                                        <?php if($item->Jumlah_Count): ?>
                                            <?php echo e($item->Jumlah_Count); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    </small>
                                </div>
                                <small><?php echo e($item->created_at); ?></small>
                                <div class="clear">
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h5>Tidak ada aspirasi ditemukan.</h5>
                    <?php endif; ?>
                    <?php echo e($aspirasi->links()); ?>

                    <div class="listAspirasi shadow mt-80">
                        <div class="headerList">
                            <img src="/uploads/img/UserProfile/<?php echo e(Auth::user()->profile); ?>" alt="User Profile">
                            <h6><?php echo e(Auth::user()->name); ?></h6>
                        </div>
                        <div class="bodyList">
                            <form action="/aspirasi/kirim" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="topic" class="col-form-label">Topik</label>
                                    <input type="text" name="topic" id="" class="form-control" required placeholder="Masukkan Topik Aspirasi Anda">
                                </div>
                                <div class="form-group">
                                    <label for="content" class="col-form-label">Aspirasi</label>
                                    <textarea name="content" id="content" cols="30" rows="10" required placeholder="Masukkan Aspirasi Anda"></textarea>
                                </div>
                                <button type="submit" class="btn button-success">Kirim Aspirasi</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rightSide">
                <div class="boxSearch">
                    <form action="/aspirasi/cari" method="get" class="">
                        <?php echo csrf_field(); ?>
                        <div class="bordered">
                            <input type="text" name="key" id="" placeholder="Cari informasi di sini">
                            <button type="submit"><i class="fa fa-search"></i></button>
                        </div>
                    </form>
                </div>
                <div class="rekomendasi">
                    <h5>Rekomendasi</h5>
                    <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div data-aos="flip-right" class="listRekomendasi shadow-sm"
                            onclick="window.location.href='/aspirasi/tanggapan/<?php echo e($item->id); ?>'">
                            <h6><?php echo e($item->topic); ?></h6>
                            <small><?php echo e($item->created_at); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <p><?php echo $crfoot->information; ?></p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('edit-js'); ?>
    <script src="<?php echo e(asset('js/aspirasi.js')); ?>" defer></script>
    <script src="//cdn.ckeditor.com/4.15.1/basic/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('content');

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/aspirasi/index.blade.php ENDPATH**/ ?>