<?php $__env->startSection('title', 'Pengunjung'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="/css/dashboard.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="header-right shadow-sm">
        <h4><span><i class="fas fa-tachometer-alt"></i></span><span>Dashboard</span></h4>
        <p>Dashboard / </p>
    </div>
    <div class="content-right">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="midContent shadow-sm">
            <h3>Selamat Datang</h3>
            <?php echo $welcome->information; ?>

        </div>
    </div>
    <div class="footer-right">
        <p><?php echo e($crfoot->information); ?></p>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('edit-js'); ?>
    <script src="<?php echo e(asset('js/dashboard.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultthree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/pengunjung/index.blade.php ENDPATH**/ ?>