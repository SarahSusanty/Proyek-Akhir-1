<?php $before = 0;?>
<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($item->idUser == Auth::user()->id): ?>
<div class="rightMessages">
    <?php if($before !=  $item->idUser): ?>
    <a href="" class="float-right hapusPesan" onclick="return deleteMessage(this)" data-id='<?php echo e($item->id); ?>'><i class="fas fa-trash-alt"></i> <span>Hapus</span></a>
    <div class="profileMessage">
        <strong><b><?php echo e('Anda'); ?></b></strong>
    </div>
    <?php else: ?>
    <a href="" class="float-right hapusPesan" onclick="return deleteMessage(this)" data-id='<?php echo e($item->id); ?>'><i class="fas fa-trash-alt"></i> <span>Hapus</span></a>
    <div class="clear"></div>
    <?php endif; ?>
    <?php if($item->picture != NULL): ?>
        <div class="imgTemp" style="width: 250px;">
            <img src="/uploads/message/img/<?php echo e($item->picture); ?>" alt="" style="max-width: 100%;">
        </div>
    <?php endif; ?>
    <?php if($item->document != NULL): ?>
    <div class="itemFileM black shadow">
        <a target="_blank" href="/uploads/message/document/<?php echo e($item->document); ?>"><i class="fas fa-download"></i></a>
        <?php $temp = explode('.', $item->document);?>
        <?php if($temp[1] == 'pdf'): ?>
        <i class="fas fa-file-pdf red"></i>
        <?php elseif($temp[1] == 'docx' || $temp[1] == 'docx'): ?>
        <i class="fas fa-file-word blue"></i>
        <?php elseif($temp[1] == 'xlsx' || $temp[1] == 'xls'): ?>
        <i class="fas fa-file-excel green"></i>
        <?php else: ?>
        <i class="fas fa-file-upload blueLight"></i>
        <?php endif; ?>
        <div class="spesifikasi">
            <small><?php echo e($item->document); ?></small><br>
        </div>
    </div>
    <?php endif; ?>
    <pre><?php echo e($item->message); ?></pre>
    <small><?php echo e($item->created_at); ?></small>
</div>
<div class="clear"></div>
<?php else: ?>
<div class="leftMessages">
    <?php if($before !=  $item->idUser): ?>
    <div class="profileMessage">
        <strong><b><?php echo e($item->name); ?></b></strong>
    </div>
    <?php endif; ?>
    <?php if($item->picture != NULL): ?>
        <div class="imgTemp" style="width: 250px;">
            <img src="/uploads/message/img/<?php echo e($item->picture); ?>" alt="" style="max-width: 100%;">
        </div>
    <?php endif; ?>
    <?php if($item->document != NULL): ?>
    <div class="itemFileM black shadow">
        <a target="_blank" href="/uploads/message/document/<?php echo e($item->document); ?>"><i class="fas fa-download"></i></a>
        <?php $temp = explode('.', $item->document);?>
        <?php if($temp[1] == 'pdf'): ?>
        <i class="fas fa-file-pdf red"></i>
        <?php elseif($temp[1] == 'docx' || $temp[1] == 'docx'): ?>
        <i class="fas fa-file-word blue"></i>
        <?php elseif($temp[1] == 'xlsx' || $temp[1] == 'xls'): ?>
        <i class="fas fa-file-excel green"></i>
        <?php else: ?>
        <i class="fas fa-file-upload blueLight"></i>
        <?php endif; ?>
        <div class="spesifikasi">
            <small><?php echo e($item->document); ?></small><br>
        </div>
    </div>
    <?php endif; ?>
    <pre><?php echo e($item->message); ?></pre>
    <small><?php echo e($item->created_at); ?></small>
</div>
<?php endif; ?>
<?php $before =$item->idUser?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/pengunjung/rowMessages.blade.php ENDPATH**/ ?>