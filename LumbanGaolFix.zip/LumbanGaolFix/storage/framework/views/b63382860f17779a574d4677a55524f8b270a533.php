<?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td style="width: 40px;text-align:center;"><input type="checkbox" name="idFiles" id="<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>"></td>
    <td style="width: 50%;"><img src="/uploads/img/AsetWeb/FileManager-IconVideo.png" alt="" width="40px"> <a target="_blank" href="<?php echo e($item->location.$item->name); ?>"><?php echo e($item->name); ?></a></td>
    <td style="width: 170px;text-align:center;"><?php echo e($item->created_at); ?></td>
    <td style="width: calc(50%-190px);text-align:center;">
        <a href="" class="btn btn-info mr-2" onclick="return SetData($('#<?php echo e($item->id); ?>'))">
            <i class="fas fa-plus"></i>
        </a>
        <a href="#" onclick="return DeleteFile( $('#<?php echo e($item->id); ?>'), 'videos')" class="btn btn-danger" id="btn-<?php echo e($item->id); ?>">
            <i class="fas fa-trash-alt"></i>
            <span class="spinner-border spinner-border-sm visibility"></span>
        </a>
    </td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/FileManager/video.blade.php ENDPATH**/ ?>