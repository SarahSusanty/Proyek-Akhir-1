<?php $__env->startSection('title', 'Aspirasi'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="/css/aspirasi.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="padding-default">
        <div class="headerPage" style="background: url(<?php echo e(asset('uploads/img/AsetWeb/' . $bgHead->picture)); ?>)"
            data-aos="fade-down">
            <h2><?php echo e($header->name); ?></h2>
           <?php echo $header->information; ?>

        </div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/aspirasi">Aspirasi</a></li>
                <li class="breadcrumb-item active" aria-current="page">Tanggapan</li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($aspirasi->topic); ?></li>
            </ol>
        </nav>
        <div class="contentRow">
            <div class="leftSide">
                <div class="contentLeft">
                    <div class="listAspirasi shadow-sm" data-aos="fade-up">
                        <div class="headerList">
                            <img src="/uploads/img/UserProfile/<?php echo e($aspirasi->profile); ?>" alt="User Profile">
                            <h6><?php echo e($aspirasi->name); ?></h6>
                        </div>
                        <h6>Topik : <?php echo e($aspirasi->topic); ?></h6>
                        <div class="bodyList">
                            <?php echo $aspirasi->aspiration; ?>

                        </div>
                        <div class="footerList">
                            <small> Jumlah Tanggapan :
                                <?php if($aspirasi->Jumlah_Count): ?>
                                    <?php echo e($aspirasi->Jumlah_Count); ?>

                                <?php else: ?>
                                    0
                                <?php endif; ?>
                            </small>
                        </div>
                        <small><?php echo e($aspirasi->created_at); ?></small>
                        <div class="clear">
                        </div>
                    </div>
                    <h5>Tanggapan</h5>
                    <?php $__currentLoopData = $replays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="listReplay shadow" data-aos="flip-right">
                        <div class="headerList">
                            <img src="/uploads/img/UserProfile/<?php echo e($item->profile); ?>" alt="User Profile">
                            <h6><?php echo e($item->name); ?></h6>
                        </div>
                        <div class="bodyList">
                            <?php echo $item->replay; ?>

                        </div>
                        <small><?php echo e($item->created_at); ?></small>
                        <div class="clear">
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="listAspirasi shadow mt-80">
                        <div class="headerList">
                            <img src="/uploads/img/UserProfile/<?php echo e(Auth::user()->profile); ?>" alt="User Profile">
                            <h6><?php echo e(Auth::user()->name); ?></h6>
                        </div>
                        <div class="bodyList">
                            <form action="/aspirasi/tanggapan/kirim" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="idAspirasi" value="<?php echo e($aspirasi->id); ?>">
                                <div class="form-group">
                                    <label for="content" class="col-form-label">Tanggapan</label>
                                    <textarea name="content" id="content" cols="30" rows="10"></textarea>
                                </div>
                                <button type="submit" class="btn button-success">Kirim Tanggapan</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rightSide">
                <div class="boxSearch">
                    <form action="/aspirasi/cari" method="get" class="">
                        <?php echo csrf_field(); ?>
                       <div class="bordered">
                        <input type="text" name="key" id="" placeholder="Cari informasi di sini">
                        <button type="submit"><i class="fa fa-search"></i></button>
                       </div>
                    </form>
                </div>
                <div class="rekomendasi">
                    <h5>Rekomendasi</h5>
                    <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div data-aos="flip-right" class="listRekomendasi shadow-sm" onclick="window.location.href='/aspirasi/tanggapan/<?php echo e($item->id); ?>'">
                            <h6><?php echo e($item->topic); ?></h6>
                            <small><?php echo e($item->created_at); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <p><?php echo $crfoot->information; ?></p>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('edit-js'); ?>
    <script src="<?php echo e(asset('js/aspirasi.js')); ?>" defer></script>
    <script src="//cdn.ckeditor.com/4.15.1/basic/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('content');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/aspirasi/tanggapan.blade.php ENDPATH**/ ?>