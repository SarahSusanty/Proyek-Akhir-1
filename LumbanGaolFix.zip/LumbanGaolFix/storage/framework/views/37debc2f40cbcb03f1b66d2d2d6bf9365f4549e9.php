<?php $__env->startSection('title', 'Admin'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="/css/admin.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="header-right shadow-sm">
        <h4><span><i class="fas fa-server"></i></span><span>Data Web</span></h4>
        <p><a href="/admin/Data">Data Web</a> / <?php echo e($type); ?></p>
    </div>
    <div class="content-right">
        <div class="bigContent">
            <?php if($type == 'links'): ?>
                <h3>Links</h3>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $tempt = explode('|', $item->information);
                ?>
                <div class="ListTempt">
                    <div class="listContent-big shadow clear">
                        <div class="setting">
                            <a href="/admin/Data/<?php echo e($type); ?>/edit/<?php echo e($item->id); ?>" class="btn btn-info"><i class="fas fa-edit"></i> Edit</a>
                        </div>
                        <div class="headerList">
                            <h5><?php echo e($item->name); ?></h5>
                        </div>
                        <div class="bodyList">
                            <ol>
                                <?php $__currentLoopData = $tempt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo $item2; ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        <div class="note">
                            <h6>Note!</h6>
                            <?php echo $item->description; ?>

                        </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php elseif($type == 'slider'): ?>
            <h3>Slider</h3>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $sliderSpef = [];
                $temp = explode("#",  $item->information);
                for ($i=0; $i < count($temp); $i++) {
                     $sliderSpef[$i] = explode("|", $temp[$i]);
                 }
                 $sliderPic =  explode("#", $item->picture);
            ?>
            <div class="ListTempt">
                <div class="listContent-big shadow clear">
                    <div class="setting">
                        <a href="/admin/Data/<?php echo e($type); ?>/edit/<?php echo e($item->id); ?>" class="btn btn-info"><i class="fas fa-edit"></i> Edit</a>
                    </div>
                    <div class="headerList">
                        <h5><?php echo e($item->name); ?></h5>
                    </div>
                    <div class="bodyList">
                        <ol>
                            <?php for($i = 0; $i < count($temp); $i++): ?>
                                <li>Judul : <?php echo $sliderSpef[$i][0]; ?> <br />
                                    Desc : <?php echo $sliderSpef[$i][1]; ?> <br />
                                    <img src="/uploads/img/AsetWeb/Carousel/<?php echo e($sliderPic[$i]); ?>" alt="Gambar Slide" width="80%">
                                </li>
                            <?php endfor; ?>
                        </ol>
                    <div class="note">
                        <h6>Note!</h6>
                        <?php echo $item->description; ?>

                    </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php elseif($type == 'header'): ?>
            <h3>Header</h3>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="ListTempt">
                    <div class="listContent-big shadow clear">
                        <div class="setting">
                            <a href="/admin/Data/<?php echo e($type); ?>/edit/<?php echo e($item->id); ?>" class="btn btn-info"><i class="fas fa-edit"></i> Edit</a>
                        </div>
                        <div class="headerList">
                            <h5><?php echo e($item->name); ?></h5>
                        </div>
                        <div class="bodyList">
                            <b>Header Text</b> : <?php echo $item->name; ?> <br/>
                            <b>Description</b> : <?php echo $item->information; ?>

                        <div class="note">
                            <h6>Note!</h6>
                            <?php echo $item->description; ?>

                        </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php elseif($type == 'text'): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="ListTempt">
                <div class="listContent-big shadow clear">
                    <div class="setting">
                        <a href="/admin/Data/<?php echo e($type); ?>/edit/<?php echo e($item->id); ?>" class="btn btn-info"><i class="fas fa-edit"></i> Edit</a>
                    </div>
                    <div class="headerList">
                        <h5><?php echo e($item->name); ?></h5>
                    </div>
                    <div class="bodyList">
                        <?php echo $item->information; ?><br/>
                    <?php if($item->picture !== NULL): ?>
                    <div class="lampiran">
                        <strong>Lampiran</strong><br>
                        <img src="/uploads/img/AsetWeb/<?php echo e($item->picture); ?>" alt="Lampiran"  style="text-align: center;"><br>
                    </div>
                    <?php endif; ?>
                    <div class="note">
                        <h6>Note!</h6>
                        <?php echo $item->description; ?>

                    </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php elseif($type == 'logo'): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="ListTempt">
                <div class="listContent-big shadow clear">
                    <div class="setting">
                        <a href="/admin/Data/<?php echo e($type); ?>/edit/<?php echo e($item->id); ?>" class="btn btn-info"><i class="fas fa-edit"></i> Edit</a>
                    </div>
                    <div class="headerList">
                        <h5><?php echo e($item->name); ?></h5>
                    </div>
                    <div class="bodyList">
                        <?php if($item->picture !== NULL): ?>
                    <div class="lampiran">
                        <strong>Lampiran</strong><br>
                        <img src="/uploads/img/AsetWeb/<?php echo e($item->picture); ?>" alt="Lampiran" width="100px" ><br>
                    </div>
                    <?php endif; ?>
                        <?php echo $item->information; ?>

                    <div class="note">
                        <h6>Note!</h6>
                        <?php echo $item->description; ?>

                    </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php elseif($type == 'background'): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="ListTempt">
                <div class="listContent-big shadow clear">
                    <div class="setting">
                        <a href="/admin/Data/<?php echo e($type); ?>/edit/<?php echo e($item->id); ?>" class="btn btn-info"><i class="fas fa-edit"></i> Edit</a>
                    </div>
                    <div class="headerList">
                        <h5><?php echo e($item->name); ?></h5>
                    </div>
                    <div class="bodyList">
                        <?php echo $item->information; ?>

                        <img src="/uploads/img/AsetWeb/<?php echo e($item->picture); ?>" alt="Lampiran" width="70%" ><br>
                    <div class="note">
                        <h6>Note!</h6>
                        <?php echo $item->description; ?>

                    </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                Tidak Ditemukan
            <?php endif; ?>
        </div>
    </div>
    <div class="footer-right">
        <p><?php echo e($crfoot->information); ?></p>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('edit-js'); ?>
    <script src="<?php echo e(asset('js/admin.js')); ?>" defer></script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultfour', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/admin/dataWebType.blade.php ENDPATH**/ ?>