<?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="listForum shadow">
        <?php if($item->counts != 0): ?>
            <div class="pesanbaru"><?php echo e($item->counts); ?></div>
        <?php endif; ?>
        <div class="flex-baru-row"
            onclick="window.location.href='/pengunjung/<?php echo e(base64_encode($item->id)); ?>/messages'">
            <div class="logoForum">
                <img src="/uploads/img/Forums/Logo/<?php echo e($item->logo); ?>" alt="">
            </div>
            <div class="descForum">
                <h5><?php echo e($item->name); ?></h5>
                <?php echo $item->description; ?>

            </div>
        </div>
        <a onclick="return ajaxSend('/pengunjung/forum/keluar','post',{'idForum': <?php echo e($item->id); ?>}, null,[['liveSearch','/pengunjung/liveSearchForum','1', '.rowForums', key]], 'Apakah anda ingin keluar dari forum ?', 'berhasil') " href="#" class="btn btn-danger"><i
                class="fas fa-sign-out-alt"></i> Keluar Dari Forum</a>
        <div class="clear"></div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($forums->links()); ?>

<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/pengunjung/rowForums.blade.php ENDPATH**/ ?>