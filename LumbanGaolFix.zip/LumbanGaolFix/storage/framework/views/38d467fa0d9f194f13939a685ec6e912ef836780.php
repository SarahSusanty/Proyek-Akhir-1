<?php $__currentLoopData = $aspirasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="listAspirasi shadow clear">
        <?php if($item->created_at >= $limitDate): ?>
            <div class="new">
                <p>New</p>
            </div>
        <?php endif; ?>
        <h6>Topic : <?php echo e($item->topic); ?> </h6>
        <div class="aspiration">
            <?php echo $item->aspiration; ?>

        </div>
        <?php if($item->status == 'approved' || $item->status == 'blocked'): ?>
        <a id="btnDelete<?php echo e($item->id); ?>" class="btn btn-danger"  onclick="return ajaxSend('/pengunjung/aspirasi/delete','post',{'idAspirasi': <?php echo e($item->id); ?>}, null,[['paginate','/pengunjung/paginate/all/aspirasi','all','1','.rowAspirasi']], 'Apakah anda ingin menghapus aspirasi ?', 'Berhasil menghapus aspirasi !', [['CreateSpin','#btnDelete<?php echo e($item->id); ?>']])">
            <i class="fas fa-trash-alt"></i><span class='text-btn'> Hapus</span>
            <span class="spinner-border spinner-border-sm displayNone icon-loading"></span>
            <span class='text-loading displayNone'>Sedang Menghapus</span>
        </a>
        <?php else: ?>
        <a class="btn button-info" href="/pengunjung/aspirasi/edit/<?php echo e(base64_encode($item->id)); ?>" ><i class="fas fa-edit"></i> Edit</a>
        <a id="btnDelete<?php echo e($item->id); ?>" class="btn btn-danger"  onclick="return ajaxSend('/pengunjung/aspirasi/delete','post',{'idAspirasi': <?php echo e($item->id); ?>}, null,[['paginate','/pengunjung/paginate/all/aspirasi','all','1','.rowAspirasi']], 'Apakah anda ingin menghapus aspirasi ?', 'Berhasil menghapus aspirasi !', [['CreateSpin','#btnDelete<?php echo e($item->id); ?>']])">
            <i class="fas fa-trash-alt"></i><span class='text-btn'> Hapus</span>
            <span class="spinner-border spinner-border-sm displayNone icon-loading"></span>
            <span class='text-loading displayNone'>Sedang Menghapus</span>
        </a>
        <?php endif; ?>
        <?php if($item->status == 'approved'): ?>
            <div class="approved">
                <i class="fas fa-check"></i>
                Diterima
            </div>
        <?php else: ?>
            <?php if($item->status == 'waiting'): ?>
                <div class="waiting">
                    <i class="fas fa-stopwatch"></i>
                    Menunggu
                </div>
            <?php else: ?>
                <?php if($item->status == 'rejected'): ?>
                    <div class="rejected">
                        <i class="fas fa-times-circle"></i>
                        Ditolak
                    </div>
                <?php else: ?>
                    <div class="rejected">
                        <i class="fas fa-ban"></i>
                        Diblokir
                    </div>
                <?php endif; ?>

            <?php endif; ?>
        <?php endif; ?>

        <div class="clear"></div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($aspirasi->links()); ?>

<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/pengunjung/rowAspirasi.blade.php ENDPATH**/ ?>