<?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="listForum shadow">
        <?php if($item->counts != 0): ?>
            <div class="pesanbaru"><?php echo e($item->counts); ?></div>
        <?php endif; ?>
        <div class="flex-baru-row">
            <div class="logoForum">
                <img src="/uploads/img/Forums/Logo/<?php echo e($item->logo); ?>" alt="">
            </div>
            <div class="descForum">
                <h5><?php echo e($item->name); ?></h5>
                <?php echo $item->description; ?>

            </div>
        </div>
        <div class="waiting">
            <i class="fas fa-watch"></i> Menunggu
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($forums->links()); ?>

<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/pengunjung/rowForumsMenunggu.blade.php ENDPATH**/ ?>