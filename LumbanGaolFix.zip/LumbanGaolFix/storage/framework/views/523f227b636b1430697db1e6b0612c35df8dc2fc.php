<h6> <i class="fas fa-image"></i> Gambar</h6>
<div class="rowFiles">
<?php if($pictures->isEmpty()): ?>
    <h3>Belum ada Gambar</h3>
<?php else: ?>
<?php $__currentLoopData = $pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="file shadow hover">
    <div class="fileSetting">
        <a  class="btn btn-danger deletePicture" onclick="return DeleteTrigger(this, '/admin/galeri/delete/pictures', 'pictures')" data-idFiles = "<?php echo e($item->id); ?>">
            <i class="fas fa-trash-alt"></i>
            <span class="spinner-border spinner-border-sm displayNone"></span>
        </a>
    </div>
    <img class="mt-2" src="<?php echo e($item->location . $item->name); ?>" alt="Foto">
    <p><?php echo e($item->name); ?></p>
    <small><?php echo e($item->created_at); ?></small>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</div>

<?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/admin/galeriPicture.blade.php ENDPATH**/ ?>