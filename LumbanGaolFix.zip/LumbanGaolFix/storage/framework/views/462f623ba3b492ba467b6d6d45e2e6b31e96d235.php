<?php $__env->startSection('title', 'Dashbord'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="/css/beranda.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="demo" class="carousel slide carousel-fade" data-ride="carousel" data-interval="5000">
        <ul class="carousel-indicators">
            <?php for($i = 0; $i < count($sliderSpef); $i++): ?>
            <li data-target="#demo" data-slide-to="<?php echo e($i); ?>" class="<?php if($i == 0): ?>
             <?php echo e(__('active')); ?>

            <?php endif; ?>"></li>
        <?php endfor; ?>
        </ul>
        <div class="carousel-inner">
            <?php for($i = 0; $i < count($sliderSpef); $i++): ?>
                <div class="carousel-item">
                <img src="/uploads/img/AsetWeb/Carousel/<?php echo e($sliderPic[$i]); ?>" alt="Los Angeles" width="100%"
                    height="">
                <h2 class="animasi-ketik"><?php echo $sliderSpef[$i][0]; ?></h2>
                <div class="carousel-caption">
                    <p><?php echo $sliderSpef[$i][1]; ?></p>
                </div>
            </div>
            <?php endfor; ?>
        </div>
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>
    <div class="padding-default content ">
        <div class="flex-baru-row">
            <?php $__currentLoopData = $informasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-information shadow" data-aos="flip-right">
                    <div class="img-display">
                        <img src="/uploads/img/Album/<?php echo e($item->name); ?>" alt="Display Informasi">
                    </div>
                    <div class="des-information">
                        <h5><?php echo e($item->title); ?></h5>
                        <p><?php echo e($item->description); ?></p>
                        <a href="/informasi/baca/<?php echo e($item->id); ?>" class="btn button-info">Lihat Informasi Lengkap</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="tentangDesa flex-baru-row-reverse shadow mt-80" data-aos="fade-up">
            <div class="img-kepalaDesa">
                <img src="/uploads/img/AsetWeb/<?php echo e($sekilas->picture); ?>" alt="Kepala Desa">
            </div>
            <div class="text-tentangDesa">
                <h3><?php echo e($sekilas->name); ?></h3>
                <div class="garis-bawah "></div>
                <?php echo $sekilas->information; ?>

            </div>
        </div>

        <div class="alamat flex-baru-row-reverse mt-80 shadow" data-aos="zoom-in">
            <div class="iframe-peta">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7972.94270640077!2d99.09098957340706!3d2.3470219931579903!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x302e0406aef41841%3A0x885aae0453bd45fe!2sLumban%20Gaol%2C%20Balige%2C%20Kabupaten%20Toba%20Samosir%2C%20Sumatera%20Utara!5e0!3m2!1sid!2sid!4v1605176771531!5m2!1sid!2sid" width="100%" frameborder="10vh" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            <div class="desc-alamat">
                <h3><?php echo e($temukan->name); ?></h3>
                <div class="garis-bawah"></div>
                <?php echo $temukan->information; ?>

            </div>
        </div>
    </div>
    <div class="footer mt-80">
        <div class="padding-default flex-baru-row">
            <div class="footer-item">
                <h3><?php echo e($tentang->name); ?></h3>
                <div class="garis-bawah-putih"></div>
                <p><?php echo $tentang->information; ?></p>
            </div>
            <div class="footer-item">
                <h3>Link Terkait</h3>
                <div class="garis-bawah-putih"></div>
                <?php $__currentLoopData = $linkterkait; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?= $item?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="footer-item">
                <img src="/uploads/img/AsetWeb/<?php echo e($logolembaga->picture); ?>" alt="LogoDel">
                <img src="/uploads/img/AsetWeb/<?php echo e($logoweb->picture); ?>" alt="LogoDesa">
            </div>
        </div>
        <p class="footer-copy"><?php echo $crfoot->information; ?></p>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('edit-js'); ?>
    <script src="<?php echo e(asset('js/beranda.js')); ?>" defer  ></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/welcome.blade.php ENDPATH**/ ?>