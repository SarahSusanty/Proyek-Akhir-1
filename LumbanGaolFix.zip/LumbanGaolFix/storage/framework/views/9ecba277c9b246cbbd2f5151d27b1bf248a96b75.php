<?php $__env->startSection('title', 'Admin'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="/css/admin.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="header-right shadow-sm">
    <h4><span><i class="fas fa-tachometer-alt"></i></span><span>Dashboard</span></h4>
    <p>Dashboard / </p>
</div>
<div class="content-right">
    <div class="columns flex-baru-row">
        <div class="items shadow color1">
            <h6><i class="fa fa-users"></i> Users</h6>
            <p><?php echo e($users); ?> users</p>
        </div>
        <div class="items shadow color2">
            <h6><i class="fas fa-qrcode"></i> Informasi Desa</h6>
            <p><?php echo e($information); ?> Informasi</p>
        </div>
        <div class="items shadow color3">
            <h6><i class="fas fa-comment"></i> Aspirasi</h6>
            <p><?php echo e($aspirations); ?> aspirasi</p>
        </div>
        <div class="items shadow color4">
            <h6><i class="fas fa-comments"></i> Forum</h6>
            <p><?php echo e($forums); ?> Forum</p>
        </div>
    </div>
    <div class="midContent">
        <h3>Selamat Datang</h3>
        <?php echo $welcome->information; ?>

    </div>
</div>
<div class="footer-right">
    <p><?php echo e($crfoot->information); ?></p>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('edit-js'); ?>
    <script src="<?php echo e(asset('js/admin.js')); ?>" defer></script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultfour', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/admin/index.blade.php ENDPATH**/ ?>