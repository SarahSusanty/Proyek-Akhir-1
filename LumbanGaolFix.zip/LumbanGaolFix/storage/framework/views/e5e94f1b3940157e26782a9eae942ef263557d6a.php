<?php $__env->startSection('title', 'Admin'); ?>
<?php $__env->startSection('edit-css'); ?>
    <link rel="stylesheet" href="/css/admin.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="header-right shadow-sm">
        <h4><span><i class="fas fa-comment"></i></span><span>Aspirasi</span></h4>
        <p><a href="/admin/aspirasi">Aspirasi</a> / Aspirasi Dilarang</p>
    </div>
    <div class="content-right">
        <div class="columns flex-baru-row">
            <div class="bigContent">
                <h3>Semua Aspirasi</h3>

                <div class="rowAspirasi">
                    <?php $__currentLoopData = $aspirations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="listAspirasi shadow">
                            <div class="userInfo">
                                <img src="/uploads/img/UserProfile/<?php echo e($item->profile); ?>" alt="">
                                <h6><?php echo e($item->name); ?></h6>
                            </div>
                            <div class="aspirasi">
                                <h6>Topik: <?php echo e($item->topic); ?></h6>
                                <?php echo $item->aspiration; ?>

                            </div>
                            <?php if($item->status == 'approved'): ?>
                                <div class="approved">
                                    <i class="fas fa-check"></i>
                                    Diterima
                                </div>
                            <?php else: ?>
                                <?php if($item->status == 'waiting'): ?>
                                    <div class="waiting">
                                        <i class="fas fa-stopwatch"></i>
                                        Menunggu
                                    </div>
                                <?php else: ?>
                                    <?php if($item->status == 'rejected'): ?>
                                        <div class="rejected">
                                            <i class="fas fa-times-circle"></i>
                                            Ditolak
                                        </div>
                                    <?php else: ?>
                                        <div class="rejected">
                                            <i class="fas fa-ban"></i>
                                            Diblokir
                                        </div>
                                    <?php endif; ?>

                                <?php endif; ?>
                            <?php endif; ?>
                            <strong><?php echo e($item->created_at); ?></strong>
                            <a href="#" class="btn btn-danger" onclick="return confirmAspirasi('batalkan',<?php echo e($item->id); ?> ,'/admin/aspirasi/menunggu', this)">
                                <i class="fas fa-ban"></i> <span class='text-btn'>Batalkan Blokir</span>
                                <span class="spinner-border spinner-border-sm displayNone icon-loading"></span>
                                <span class='text-loading displayNone'>Sedang Membatalkan Konfirmasi</span>
                            </a>
                            <div class="clear"></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php echo e($aspirations->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <div class="footer-right">
        <p><?php echo e($crfoot->information); ?></p>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('edit-js'); ?>
    <script src="<?php echo e(asset('js/admin.js')); ?>" defer></script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultfour', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelProject\PAP\LumbanGaolFix\resources\views/admin/aspirasiBlokir.blade.php ENDPATH**/ ?>